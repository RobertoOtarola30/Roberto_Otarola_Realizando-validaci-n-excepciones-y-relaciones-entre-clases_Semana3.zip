package model;

public class Cliente extends Persona {
    private String categoriaFrecuencia; // Ej: Regular, VIP, Corporativo
    private boolean requiereAsistenciaEspecial;

    public Cliente(String rut, String nombre, String correo, String telefono,
                   Direccion direccion, String categoriaFrecuencia, boolean requiereAsistenciaEspecial) {
        super(rut, nombre, correo, telefono, direccion);
        this.categoriaFrecuencia = categoriaFrecuencia;
        this.requiereAsistenciaEspecial = requiereAsistenciaEspecial;
    }

    public String getCategoriaFrecuencia() {
        return categoriaFrecuencia;
    }

    public void setCategoriaFrecuencia(String categoriaFrecuencia) {
        this.categoriaFrecuencia = categoriaFrecuencia;
    }

    public boolean isRequiereAsistenciaEspecial() {
        return requiereAsistenciaEspecial;
    }

    public void setRequiereAsistenciaEspecial(boolean requiereAsistenciaEspecial) {
        this.requiereAsistenciaEspecial = requiereAsistenciaEspecial;
    }

    @Override
    public String toString() {
        return "[CLIENTE] " + super.toString() +
                " | Categoría: " + categoriaFrecuencia +
                " | Asistencia Especial: " + (requiereAsistenciaEspecial ? "Sí" : "No");
    }
}