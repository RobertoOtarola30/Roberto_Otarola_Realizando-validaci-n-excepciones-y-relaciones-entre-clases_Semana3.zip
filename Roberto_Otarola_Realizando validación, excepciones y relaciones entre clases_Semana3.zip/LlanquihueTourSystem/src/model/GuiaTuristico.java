package model;

public class GuiaTuristico extends Persona {
    private String especialidad;
    private int aniosExperiencia;
    private String idiomaPrincipal;

    public GuiaTuristico(String rut, String nombre, String correo, String telefono,
                         Direccion direccion, String especialidad, int aniosExperiencia, String idiomaPrincipal) {
        super(rut, nombre, correo, telefono, direccion);
        this.especialidad = especialidad;
        this.aniosExperiencia = aniosExperiencia;
        this.idiomaPrincipal = idiomaPrincipal;
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public int getAniosExperiencia() { return aniosExperiencia; }
    public void setAniosExperiencia(int aniosExperiencia) { this.aniosExperiencia = aniosExperiencia; }

    public String getIdiomaPrincipal() { return idiomaPrincipal; }
    public void setIdiomaPrincipal(String idiomaPrincipal) { this.idiomaPrincipal = idiomaPrincipal; }

    @Override
    public String toString() {
        return "[GUÍA TURÍSTICO] " + super.toString() +
                " | Especialidad: " + especialidad +
                " | Años Exp: " + aniosExperiencia +
                " | Idioma: " + idiomaPrincipal;
    }
}