package app;

import model.Cliente;
import model.Direccion;
import model.GuiaTuristico;
import model.Persona;

public class Main {
    public static void main(String[] args) {
        System.out.println("==================================================================");
        System.out.println("          SISTEMA DE GESTIÓN - LLANQUIHUE TOUR                   ");
        System.out.println("==================================================================\n");

        Direccion dir1 = new Direccion("Costanera", 450, "Llanquihue");
        Direccion dir2 = new Direccion("Calle Techada", 120, "Puerto Varas");
        Direccion dir3 = new Direccion("Av. Vicente Pérez Rosales", 1350, "Ensenada");

        Persona personaBase = new Persona("15.432.123-K", "Carlos Soto", "carlos.soto@gmail.com", "+56912345678", dir1);

        GuiaTuristico guia = new GuiaTuristico("18.987.654-3", "Valentina Rojas", "v.rojas@llanquihuetour.cl", "+56987654321", dir2,
                "Rutas Gastronómicas y Trekking Volcán Calbuco", 5, "Español/Inglés");

        Cliente cliente = new Cliente("20.111.222-9", "Martin Hempel", "m.hempel@yahoo.com", "+56933334444", dir3,
                "VIP", false);

        System.out.println("--- Registro 1: Persona Base / Colaborador ---");
        System.out.println(personaBase);
        System.out.println();

        System.out.println("--- Registro 2: Guía Turístico (Extiende Persona) ---");
        System.out.println(guia);
        System.out.println();

        System.out.println("--- Registro 3: Cliente (Extiende Persona) ---");
        System.out.println(cliente);
        System.out.println();

        System.out.println("==================================================================");
        System.out.println("         EJECUCIÓN FINALIZADA EXITOSAMENTE                        ");
        System.out.println("==================================================================");
    }
}